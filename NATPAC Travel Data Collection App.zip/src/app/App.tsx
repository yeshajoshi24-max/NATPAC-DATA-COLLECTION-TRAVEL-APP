import { useState } from 'react';
import { SplashScreen } from './components/splash-screen';
import { LoginScreen } from './components/login-screen';
import { SignupScreen } from './components/signup-screen';
import { WelcomeScreen } from './components/welcome-screen';
import { PrivacyConsent } from './components/privacy-consent';
import { MainDashboard } from './components/main-dashboard';
import { NatpacLogin } from './components/natpac-login';
import { NatpacDashboard } from './components/natpac-dashboard';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'splash' | 'login' | 'signup' | 'welcome' | 'consent' | 'dashboard' | 'natpac-login' | 'natpac-dashboard'>('splash');

  const handleSplashComplete = () => {
    setCurrentScreen('login');
  };

  const handleLogin = () => {
    setCurrentScreen('dashboard');
  };

  const handleSignup = () => {
    setCurrentScreen('welcome');
  };

  const handleGoToSignup = () => {
    setCurrentScreen('signup');
  };

  const handleSkipSignup = () => {
    setCurrentScreen('welcome');
  };

  const handleNatpacLogin = () => {
    setCurrentScreen('natpac-login');
  };

  const handleBackToLogin = () => {
    setCurrentScreen('login');
  };

  const handleNatpacAccess = () => {
    setCurrentScreen('natpac-dashboard');
  };

  const handleNatpacLogout = () => {
    setCurrentScreen('login');
  };

  const handleWelcomeContinue = () => {
    setCurrentScreen('consent');
  };

  const handleConsentAccept = () => {
    setCurrentScreen('dashboard');
  };

  const handleConsentDecline = () => {
    // In a real app, this might exit or show an alternative flow
    setCurrentScreen('welcome');
  };

  const handleUserLogout = () => {
    setCurrentScreen('login');
  };

  return (
    <div className="size-full">
      {currentScreen === 'splash' && (
        <SplashScreen onComplete={handleSplashComplete} />
      )}
      {currentScreen === 'login' && (
        <LoginScreen 
          onLogin={handleLogin} 
          onSignup={handleGoToSignup}
          onNatpacLogin={handleNatpacLogin}
        />
      )}
      {currentScreen === 'signup' && (
        <SignupScreen onSignup={handleSignup} onSkip={handleSkipSignup} />
      )}
      {currentScreen === 'natpac-login' && (
        <NatpacLogin 
          onLogin={handleNatpacAccess}
          onBack={handleBackToLogin}
        />
      )}
      {currentScreen === 'natpac-dashboard' && (
        <NatpacDashboard onLogout={handleNatpacLogout} />
      )}
      {currentScreen === 'welcome' && (
        <WelcomeScreen onContinue={handleWelcomeContinue} />
      )}
      {currentScreen === 'consent' && (
        <PrivacyConsent 
          onAccept={handleConsentAccept} 
          onDecline={handleConsentDecline} 
        />
      )}
      {currentScreen === 'dashboard' && (
        <MainDashboard onLogout={handleUserLogout} />
      )}
    </div>
  );
}