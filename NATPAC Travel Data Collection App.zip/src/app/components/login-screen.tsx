import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader } from './ui/card';
import { MapPin, Mail, Lock, ArrowRight, User } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
  onSignup: () => void;
  onNatpacLogin: () => void;
}

export function LoginScreen({ onLogin, onSignup, onNatpacLogin }: LoginScreenProps) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isFormValid = formData.email && formData.password;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      onLogin();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50">
      {/* Header */}
      <div className="relative h-40 overflow-hidden bg-gradient-to-br from-emerald-600 via-green-600 to-teal-600">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4 text-white text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <MapPin className="h-6 w-6 text-emerald-400" />
            <h1 className="text-xl">OriGo</h1>
          </div>
          <p className="text-sm opacity-90">Building Kerala's future together</p>
        </div>
      </div>

      <div className="p-4 pb-32">
        <div className="max-w-md mx-auto">
          {/* Welcome Message */}
          <div className="text-center mb-8">
            <h2 className="text-2xl mb-4 text-gray-800">
              Welcome back to OriGo
            </h2>
            <p className="text-sm text-gray-600">
              Sign in to continue your journey with Kerala's travel companion
            </p>
          </div>

          {/* Login Form */}
          <Card className="mb-6 shadow-lg border-0">
            <CardHeader className="pb-4">
              <h3 className="text-center text-gray-800">Sign In</h3>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="password"
                      placeholder="Enter your password"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    type="submit"
                    disabled={!isFormValid}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Sign In
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>

                <div className="text-center">
                  <button
                    type="button"
                    className="text-sm text-emerald-600 hover:text-emerald-700"
                  >
                    Forgot password?
                  </button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Sign Up Option */}
          <Card className="mb-6 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-200">
            <CardContent className="p-4 text-center">
              <p className="text-gray-700 mb-3">Don't have an account?</p>
              <Button
                onClick={onSignup}
                variant="outline"
                className="w-full border-emerald-300 text-emerald-700 hover:bg-emerald-50"
              >
                <User className="h-4 w-4 mr-2" />
                Create New Account
              </Button>
            </CardContent>
          </Card>

          {/* NATPAC Admin Login */}
          <div className="text-center">
            <button
              onClick={onNatpacLogin}
              className="text-sm text-blue-600 hover:text-blue-700 underline"
            >
              NATPAC admin? Login here
            </button>

          </div>
        </div>
      </div>
    </div>
  );
}