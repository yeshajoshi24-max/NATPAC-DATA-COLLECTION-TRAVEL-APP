import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { ScrollArea } from './ui/scroll-area';
import { Shield, Lock, Eye, Database, Users, MapPin, Clock } from 'lucide-react';

interface PrivacyConsentProps {
  onAccept: () => void;
  onDecline: () => void;
}

export function PrivacyConsent({ onAccept, onDecline }: PrivacyConsentProps) {
  const [consents, setConsents] = useState({
    dataCollection: false,
    locationTracking: false,
    coTravelerData: false,
    communitySharing: false,
    analytics: false
  });

  const allConsentsGiven = Object.values(consents).every(consent => consent);

  const handleConsentChange = (key: keyof typeof consents, checked: boolean) => {
    setConsents(prev => ({ ...prev, [key]: checked }));
  };

  const dataTypes = [
    {
      icon: <MapPin className="h-5 w-5 text-emerald-600" />,
      title: "Travel Routes",
      description: "Origin and destination points, mode of transport"
    },
    {
      icon: <Clock className="h-5 w-5 text-blue-600" />,
      title: "Travel Duration",
      description: "Time spent traveling and trip timestamps"
    },
    {
      icon: <Users className="h-5 w-5 text-purple-600" />,
      title: "Co-Traveler Info",
      description: "Group size and travel companions (anonymized)"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50 p-4 pb-32">
      <div className="max-w-md mx-auto pt-8">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex p-3 bg-emerald-100 rounded-full mb-4">
            <Shield className="h-8 w-8 text-emerald-600" />
          </div>
          <h1 className="text-xl mb-2 text-gray-800">Privacy & Data Consent</h1>
          <p className="text-sm text-gray-600">
            Your privacy matters. Please review and consent to data collection.
          </p>
        </div>

        <ScrollArea className="h-96 mb-6">
          <div className="space-y-4 pr-4">
            {/* Blockchain Security Notice */}
            <Card className="border-emerald-200 bg-emerald-50/50">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-emerald-600" />
                  <h3 className="text-emerald-800">Blockchain-Secured Consent</h3>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-emerald-700">
                  Your consent is recorded on blockchain for transparency and immutability. 
                  You can withdraw consent at any time.
                </p>
              </CardContent>
            </Card>

            {/* Data Collection Types */}
            <Card>
              <CardHeader className="pb-3">
                <h3 className="flex items-center gap-2 text-gray-800">
                  <Database className="h-5 w-5" />
                  Data We Collect
                </h3>
              </CardHeader>
              <CardContent className="space-y-3">
                {dataTypes.map((data, index) => (
                  <div key={index} className="flex items-start gap-3 p-2 rounded-lg bg-gray-50">
                    {data.icon}
                    <div>
                      <p className="text-sm text-gray-800">{data.title}</p>
                      <p className="text-xs text-gray-600">{data.description}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Consent Options */}
            <Card>
              <CardHeader className="pb-3">
                <h3 className="text-gray-800">Your Consent</h3>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="dataCollection"
                    checked={consents.dataCollection}
                    onCheckedChange={(checked) => handleConsentChange('dataCollection', !!checked)}
                  />
                  <div className="space-y-1 leading-none">
                    <label 
                      htmlFor="dataCollection" 
                      className="text-sm text-gray-800 cursor-pointer"
                      onClick={() => handleConsentChange('dataCollection', !consents.dataCollection)}
                    >
                      Basic travel data collection
                    </label>
                    <p className="text-xs text-gray-600">
                      Allow NATPAC to collect your travel patterns for metro planning
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="locationTracking"
                    checked={consents.locationTracking}
                    onCheckedChange={(checked) => handleConsentChange('locationTracking', !!checked)}
                  />
                  <div className="space-y-1 leading-none">
                    <label 
                      htmlFor="locationTracking" 
                      className="text-sm text-gray-800 cursor-pointer"
                      onClick={() => handleConsentChange('locationTracking', !consents.locationTracking)}
                    >
                      GPS location tracking
                    </label>
                    <p className="text-xs text-gray-600">
                      Track your location only during active travel (energy-saving mode)
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="coTravelerData"
                    checked={consents.coTravelerData}
                    onCheckedChange={(checked) => handleConsentChange('coTravelerData', !!checked)}
                  />
                  <div className="space-y-1 leading-none">
                    <label 
                      htmlFor="coTravelerData" 
                      className="text-sm text-gray-800 cursor-pointer"
                      onClick={() => handleConsentChange('coTravelerData', !consents.coTravelerData)}
                    >
                      Co-traveler information
                    </label>
                    <p className="text-xs text-gray-600">
                      Share anonymized group travel data when scanning co-travelers
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="communitySharing"
                    checked={consents.communitySharing}
                    onCheckedChange={(checked) => handleConsentChange('communitySharing', !!checked)}
                  />
                  <div className="space-y-1 leading-none">
                    <label 
                      htmlFor="communitySharing" 
                      className="text-sm text-gray-800 cursor-pointer"
                      onClick={() => handleConsentChange('communitySharing', !consents.communitySharing)}
                    >
                      Community forum participation
                    </label>
                    <p className="text-xs text-gray-600">
                      Share photos and interact in the community forum
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="analytics"
                    checked={consents.analytics}
                    onCheckedChange={(checked) => handleConsentChange('analytics', !!checked)}
                  />
                  <div className="space-y-1 leading-none">
                    <label 
                      htmlFor="analytics" 
                      className="text-sm text-gray-800 cursor-pointer"
                      onClick={() => handleConsentChange('analytics', !consents.analytics)}
                    >
                      Personal insights & analytics
                    </label>
                    <p className="text-xs text-gray-600">
                      Receive personalized travel insights and rewards
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Privacy Protection Notice */}
            <Card className="border-blue-200 bg-blue-50/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-2">
                  <Eye className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="text-sm text-blue-800 mb-1">Privacy Protection</p>
                    <p className="text-xs text-blue-700">
                      Co-traveler locations are visible to you but never shared with NATPAC admins. 
                      All personal data is encrypted and anonymized.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>

        {/* Action buttons */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-sm border-t border-gray-200">
          <div className="max-w-md mx-auto space-y-3">
            <Button
              onClick={onAccept}
              disabled={!allConsentsGiven}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Accept & Continue
            </Button>
            <Button
              onClick={onDecline}
              variant="outline"
              className="w-full py-3 rounded-xl border-gray-300"
            >
              Decline
            </Button>
            <p className="text-xs text-center text-gray-500">
              You can modify these preferences anytime in settings
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}