import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader } from './ui/card';
import { Building2, Mail, Lock, ArrowRight, ArrowLeft } from 'lucide-react';

interface NatpacLoginProps {
  onLogin: () => void;
  onBack: () => void;
}

export function NatpacLogin({ onLogin, onBack }: NatpacLoginProps) {
  const [formData, setFormData] = useState({
    adminId: '',
    password: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isFormValid = formData.adminId && formData.password;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      onLogin();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <div className="relative h-40 overflow-hidden bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute top-4 left-4">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>
        <div className="absolute bottom-4 left-4 right-4 text-white text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <Building2 className="h-6 w-6 text-blue-400" />
            <h1 className="text-xl">NATPAC Admin Portal</h1>
          </div>
          <p className="text-sm opacity-90">Kerala State Transport Planning Authority</p>
        </div>
      </div>

      <div className="p-4">
        <div className="max-w-md mx-auto">
          {/* Welcome Message */}
          <div className="text-center mb-8">
            <h2 className="text-2xl mb-4 text-gray-800">
              NATPAC Administrator
            </h2>
            <p className="text-sm text-gray-600">
              Access travel analytics and metro planning data
            </p>
          </div>

          {/* Login Form */}
          <Card className="mb-6 shadow-lg border-0">
            <CardHeader className="pb-4">
              <h3 className="text-center text-gray-800">Secure Login</h3>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Admin ID</label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Enter your admin ID"
                      value={formData.adminId}
                      onChange={(e) => handleInputChange('adminId', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="password"
                      placeholder="Enter your password"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    type="submit"
                    disabled={!isFormValid}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Access Portal
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Security Notice */}
          <Card className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border-blue-200">
            <CardContent className="p-4">
              <h4 className="text-blue-800 mb-3">Security Notice</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                  <span className="text-blue-700">All access is logged and monitored</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                  <span className="text-blue-700">Data is encrypted and secure</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                  <span className="text-blue-700">User privacy is protected</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}