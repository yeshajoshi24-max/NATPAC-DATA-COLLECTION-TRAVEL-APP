import { useEffect } from 'react';
import { MapPin, Zap } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3000); // Show splash for 3 seconds

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-emerald-900 via-green-800 to-teal-900">

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-8 text-white">
        {/* App Logo/Icon */}
        <div className="mb-8 relative">
          <div className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center border border-white/30 shadow-2xl">
            <MapPin className="h-12 w-12 text-white" />
          </div>
          {/* Animated pulse ring */}
          <div className="absolute inset-0 w-24 h-24 bg-white/10 rounded-3xl animate-ping" />
        </div>

        {/* App Name */}
        <div className="text-center mb-12">
          <h1 className="text-5xl mb-4 tracking-wider">
            OriGo
          </h1>
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-px bg-white/50 w-8"></div>
            <p className="text-lg text-white/90 px-2">Kerala Travel Companion</p>
            <div className="h-px bg-white/50 w-8"></div>
          </div>
          <p className="text-sm text-white/80 max-w-xs mx-auto leading-relaxed">
            Powered by NATPAC • Building Kerala's future together
          </p>
        </div>

        {/* Features highlight */}
        <div className="flex items-center gap-6 text-center">
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mb-2">
              <MapPin className="h-5 w-5" />
            </div>
            <p className="text-xs text-white/80">Smart Tracking</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mb-2">
              <Zap className="h-5 w-5" />
            </div>
            <p className="text-xs text-white/80">Energy Saving</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mb-2">
              <span className="text-sm">🎁</span>
            </div>
            <p className="text-xs text-white/80">Rewards</p>
          </div>
        </div>

        {/* Loading indicator */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
        </div>

        {/* Version info */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <p className="text-xs text-white/60">Version 1.0.0</p>
        </div>
      </div>
    </div>
  );
}