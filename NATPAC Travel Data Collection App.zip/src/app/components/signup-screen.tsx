import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader } from './ui/card';
import { MapPin, Mail, Phone, User, ArrowRight } from 'lucide-react';

interface SignupScreenProps {
  onSignup: () => void;
  onSkip: () => void;
}

export function SignupScreen({ onSignup, onSkip }: SignupScreenProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isFormValid = formData.name && formData.email && formData.phone;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      onSignup();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50">
      {/* Header with Kerala imagery */}
      <div className="relative h-40 overflow-hidden bg-gradient-to-br from-emerald-600 via-green-600 to-teal-600">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4 text-white text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <MapPin className="h-6 w-6 text-emerald-400" />
            <h1 className="text-xl">OriGo</h1>
          </div>
        </div>
      </div>

      <div className="p-4 pb-32">
        <div className="max-w-md mx-auto">
          {/* Welcome Message */}
          <div className="text-center mb-8">
            <h2 className="text-2xl mb-4 text-gray-800">
              Excited to start your journey with OriGo?
            </h2>
            <p className="text-lg text-emerald-700 mb-2">Sign up here</p>
            <p className="text-sm text-gray-600">
              Join thousands of Kerala travelers helping build the future of metro transportation
            </p>
          </div>

          {/* Signup Form */}
          <Card className="mb-6 shadow-lg border-0">
            <CardHeader className="pb-4">
              <h3 className="text-center text-gray-800">Create Your Account</h3>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-700">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      type="tel"
                      placeholder="+91 XXXXX XXXXX"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="pl-10 bg-gray-50 border-gray-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    type="submit"
                    disabled={!isFormValid}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Start My Journey
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Benefits */}
          <Card className="mb-6 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-200">
            <CardContent className="p-4">
              <h4 className="text-emerald-800 mb-3">Why join OriGo?</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  <span className="text-emerald-700">Earn rewards for every kilometer traveled</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  <span className="text-emerald-700">Help shape Kerala's metro future</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  <span className="text-emerald-700">Connect with fellow travelers</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  <span className="text-emerald-700">Get personalized travel insights</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Social Proof */}
          <div className="text-center mb-6">
            <p className="text-sm text-gray-600 mb-2">
              Join <span className="text-emerald-600">25,000+</span> Kerala travelers
            </p>
            <div className="flex justify-center items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <span key={star} className="text-yellow-400 text-sm">⭐</span>
              ))}
              <span className="text-xs text-gray-500 ml-1">4.8/5 rating</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Options */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-sm border-t border-gray-200">
        <div className="max-w-md mx-auto space-y-3">
          <Button
            onClick={onSkip}
            variant="outline"
            className="w-full py-3 rounded-xl border-gray-300 text-gray-600 hover:text-gray-800"
          >
            Skip for now
          </Button>
          <p className="text-xs text-center text-gray-500">
            You can always create an account later in settings
          </p>
        </div>
      </div>
    </div>
  );
}