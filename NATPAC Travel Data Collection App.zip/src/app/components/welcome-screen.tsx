import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { MapPin, Users, Camera, Zap, Shield, Gift, BarChart3, Link2 } from 'lucide-react';

interface WelcomeScreenProps {
  onContinue: () => void;
}

export function WelcomeScreen({ onContinue }: WelcomeScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const features = [
    {
      icon: <MapPin className="h-8 w-8 text-emerald-600" />,
      title: "Smart Travel Tracking",
      description: "Automatically log your daily journeys across Kerala with precise origin-to-destination mapping."
    },
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: "Co-Traveler Connect",
      description: "Scan unique QR codes to log group travels and help NATPAC understand travel patterns."
    },
    {
      icon: <Camera className="h-8 w-8 text-purple-600" />,
      title: "Community Forum",
      description: "Share scenic captures and connect with fellow travelers in Kerala."
    },
    {
      icon: <Zap className="h-8 w-8 text-yellow-600" />,
      title: "Energy Saving Mode",
      description: "GPS activates only when movement is detected, preserving your battery life."
    },
    {
      icon: <Shield className="h-8 w-8 text-red-600" />,
      title: "Blockchain Consent",
      description: "Your privacy is secured with blockchain-based consent management."
    },
    {
      icon: <Gift className="h-8 w-8 text-pink-600" />,
      title: "Travel Rewards",
      description: "Earn points and coupons for every kilometer traveled across Kerala."
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-indigo-600" />,
      title: "Personal Insights",
      description: "Get detailed analytics about your travel patterns and preferences."
    },
    {
      icon: <Link2 className="h-8 w-8 text-teal-600" />,
      title: "Smart Trip Linking",
      description: "Automatic sequencing for connected trips with unique trip IDs."
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % Math.ceil(features.length / 2));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + Math.ceil(features.length / 2)) % Math.ceil(features.length / 2));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50 flex flex-col">
      {/* Header with Kerala imagery */}
      <div className="relative h-48 overflow-hidden bg-gradient-to-br from-emerald-600 via-green-600 to-teal-600">
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4 text-white">
          <h1 className="text-2xl mb-2">OriGo</h1>
          <p className="text-sm opacity-90">Building Kerala's future together</p>
        </div>
      </div>

      {/* Features showcase */}
      <div className="flex-1 p-4 pb-20">
        <div className="max-w-md mx-auto">
          <div className="mb-6 text-center">
            <h2 className="text-lg mb-2 text-gray-800">Discover Amazing Features</h2>
            <p className="text-sm text-gray-600">Help shape Kerala's transportation future while earning rewards</p>
          </div>

          {/* Feature cards carousel */}
          <div className="space-y-4 mb-8">
            {features.slice(currentSlide * 2, (currentSlide * 2) + 2).map((feature, index) => (
              <Card key={currentSlide * 2 + index} className="border-0 shadow-sm bg-white/70 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-white rounded-lg shadow-sm">
                      {feature.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="mb-1 text-gray-800">{feature.title}</h3>
                      <p className="text-sm text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Navigation dots */}
          <div className="flex justify-center gap-2 mb-8">
            {Array.from({ length: Math.ceil(features.length / 2) }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentSlide ? 'bg-emerald-500 w-6' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Footer CTA */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/95 backdrop-blur-sm border-t border-gray-200">
        <div className="max-w-md mx-auto space-y-2">
          <Button 
            onClick={onContinue}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl"
          >
            Get Started
          </Button>
          <p className="text-xs text-center text-gray-500">
            By continuing, you agree to help improve Kerala's metro planning
          </p>
        </div>
      </div>
    </div>
  );
}