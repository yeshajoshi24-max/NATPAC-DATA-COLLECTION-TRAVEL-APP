import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Home, 
  MapPin, 
  Users, 
  Camera, 
  BarChart3, 
  Play, 
  Pause, 
  Zap, 
  Gift,
  QrCode,
  Navigation,
  Clock,
  Car,
  Bus,
  Train,
  Bike,
  LogOut
} from 'lucide-react';

interface MainDashboardProps {
  onLogout: () => void;
}

export function MainDashboard({ onLogout }: MainDashboardProps) {
  const [isTracking, setIsTracking] = useState(false);
  const [currentTrip, setCurrentTrip] = useState<any>(null);
  const [rewardPoints, setRewardPoints] = useState(1250);
  const [energySaveMode, setEnergySaveMode] = useState(true);
  const [tripHistory, setTripHistory] = useState([
    {
      id: 'TRP001',
      origin: 'Home - Kochi',
      destination: 'Office - Thiruvananthapuram',
      mode: 'bus',
      startTime: '08:30 AM',
      endTime: '10:45 AM',
      date: '2025-09-19',
      distance: 220,
      companions: 0,
      companionDetails: 'Solo Travel',
      points: 44
    },
    {
      id: 'TRP002',
      origin: 'Office - Thiruvananthapuram',
      destination: 'Shopping Mall - Kollam',
      mode: 'car',
      startTime: '06:00 PM',
      endTime: '07:30 PM',
      date: '2025-09-18',
      distance: 85,
      companions: 2,
      companionDetails: 'Spouse, Child (Age 8)',
      points: 17
    },
    {
      id: 'TRP003',
      origin: 'Home - Kochi',
      destination: 'Munnar Hills',
      mode: 'bus',
      startTime: '09:00 AM',
      endTime: '12:30 PM',
      date: '2025-09-17',
      distance: 130,
      companions: 3,
      companionDetails: 'Friends (2 Adults, 1 Child)',
      points: 26
    }
  ]);

  // Mock current trip data
  useEffect(() => {
    if (isTracking) {
      setCurrentTrip({
        id: 'TRP_' + Date.now(),
        startTime: new Date(),
        origin: 'Kochi',
        destination: 'Alappuzha',
        mode: 'bus',
        distance: 24.5,
        coTravelers: 2
      });
    } else {
      setCurrentTrip(null);
    }
  }, [isTracking]);

  const recentTrips = [
    { id: 'TRP_001', origin: 'Thiruvananthapuram', destination: 'Kochi', distance: 220, mode: 'train', date: '2024-01-15', points: 44 },
    { id: 'TRP_002', origin: 'Kochi', destination: 'Munnar', distance: 130, mode: 'bus', date: '2024-01-14', points: 26 },
    { id: 'TRP_003', origin: 'Kozhikode', destination: 'Wayanad', distance: 85, mode: 'car', date: '2024-01-13', points: 17 }
  ];

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'car': return <Car className="h-4 w-4" />;
      case 'bus': return <Bus className="h-4 w-4" />;
      case 'train': return <Train className="h-4 w-4" />;
      case 'bike': return <Bike className="h-4 w-4" />;
      default: return <Navigation className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-50">
      <Tabs defaultValue="home" className="w-full">
        {/* Tab Content */}
        <div className="pb-20">
          <TabsContent value="home" className="p-4 mt-0">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-xl text-gray-800">Good morning!</h1>
                <p className="text-sm text-gray-600">Ready for your Kerala journey?</p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onLogout}
                    className="text-gray-600 hover:text-red-600 hover:bg-red-50 p-2"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                  <div className="flex items-center gap-1 text-emerald-600">
                    <Gift className="h-4 w-4" />
                    <span className="text-sm">{rewardPoints} points</span>
                  </div>
                </div>
                <Badge variant={energySaveMode ? "default" : "secondary"} className="text-xs">
                  <Zap className="h-3 w-3 mr-1" />
                  {energySaveMode ? 'Energy Saving' : 'Normal'}
                </Badge>
              </div>
            </div>

            {/* Current Trip Card */}
            {isTracking && currentTrip ? (
              <Card className="mb-6 border-emerald-200 bg-emerald-50/50">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-emerald-800">Trip in Progress</h3>
                    <Badge className="bg-emerald-600">Live</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      {getModeIcon(currentTrip.mode)}
                      <span className="text-sm text-gray-700">
                        {currentTrip.origin} → {currentTrip.destination}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-xs text-gray-600">Distance</p>
                        <p className="text-sm text-gray-800">{currentTrip.distance} km</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Duration</p>
                        <p className="text-sm text-gray-800">45 min</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Co-travelers</p>
                        <p className="text-sm text-gray-800">{currentTrip.coTravelers}</p>
                      </div>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="mb-6">
                <CardContent className="text-center py-8">
                  <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-gray-800 mb-2">Start Your Journey</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Tap to begin tracking your Kerala travel
                  </p>
                  <Button
                    onClick={() => setIsTracking(true)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white px-8"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Start Trip
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <Card className="cursor-pointer hover:bg-gray-50 transition-colors">
                <CardContent className="text-center py-6">
                  <QrCode className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-800">Scan Co-traveler</p>
                </CardContent>
              </Card>
              <Card className="cursor-pointer hover:bg-gray-50 transition-colors">
                <CardContent className="text-center py-6">
                  <Camera className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-800">Capture Moment</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Trips */}
            <Card>
              <CardHeader className="pb-3">
                <h3 className="text-gray-800">Recent Trips</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentTrips.map((trip) => (
                    <div key={trip.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        {getModeIcon(trip.mode)}
                        <div>
                          <p className="text-sm text-gray-800">{trip.origin} → {trip.destination}</p>
                          <p className="text-xs text-gray-600">{trip.date} • {trip.distance} km</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        +{trip.points} pts
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trips" className="p-4 mt-0">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg text-gray-800">Trip History</h2>
                <Badge variant="secondary" className="text-xs">
                  {tripHistory.length} trips
                </Badge>
              </div>
              
              {/* Trip List */}
              <div className="space-y-3">
                {tripHistory.map((trip) => (
                  <Card key={trip.id} className="border-l-4 border-l-emerald-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getModeIcon(trip.mode)}
                          <span className="text-sm font-mono text-blue-600">{trip.id}</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          +{trip.points} pts
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        <div>
                          <p className="text-sm text-gray-800">{trip.origin}</p>
                          <p className="text-xs text-gray-500">↓</p>
                          <p className="text-sm text-gray-800">{trip.destination}</p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-xs text-gray-600">
                          <div>
                            <span className="block">Time: {trip.startTime} - {trip.endTime}</span>
                            <span className="block">Date: {trip.date}</span>
                          </div>
                          <div>
                            <span className="block">Distance: {trip.distance} km</span>
                            <span className="block">Mode: {trip.mode}</span>
                          </div>
                        </div>
                        
                        <div className="pt-2 border-t border-gray-100">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-600">Travelers:</span>
                            <Badge variant={trip.companions > 0 ? "default" : "secondary"} className="text-xs">
                              {trip.companions + 1} total
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{trip.companionDetails}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {/* Summary Stats */}
              <Card className="bg-emerald-50 border-emerald-200">
                <CardContent className="p-4">
                  <h3 className="text-sm font-medium text-emerald-800 mb-3">Your Travel Summary</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-emerald-700">Total Distance:</span>
                      <span className="ml-2 font-medium">{tripHistory.reduce((sum, trip) => sum + trip.distance, 0)} km</span>
                    </div>
                    <div>
                      <span className="text-emerald-700">Total Points:</span>
                      <span className="ml-2 font-medium">{tripHistory.reduce((sum, trip) => sum + trip.points, 0)} pts</span>
                    </div>
                    <div>
                      <span className="text-emerald-700">Most Used Mode:</span>
                      <span className="ml-2 font-medium capitalize">
                        {tripHistory.reduce((acc, trip) => {
                          acc[trip.mode] = (acc[trip.mode] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>).bus > 1 ? 'Bus' : 'Mixed'}
                      </span>
                    </div>
                    <div>
                      <span className="text-emerald-700">Travel Days:</span>
                      <span className="ml-2 font-medium">{new Set(tripHistory.map(t => t.date)).size} days</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="connect" className="p-4 mt-0">
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg text-gray-800 mb-2">Co-traveler Connect</h3>
              <p className="text-sm text-gray-600 mb-6">
                Scan QR codes to connect with travel companions
              </p>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <QrCode className="h-4 w-4 mr-2" />
                Open Scanner
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="community" className="p-4 mt-0">
            <div className="space-y-4">
              <h2 className="text-lg text-gray-800">Community Forum</h2>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                      <span className="text-xs text-emerald-600">RK</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-800 mb-1">Rahul K.</p>
                      <p className="text-xs text-gray-600">Captured at Munnar Hills • 2h ago</p>
                    </div>
                  </div>
                  <div className="w-full h-48 bg-gradient-to-br from-emerald-200 to-teal-300 rounded-lg mb-3 flex items-center justify-center">
                    <Camera className="h-12 w-12 text-emerald-600" />
                  </div>
                  <p className="text-sm text-gray-700 mb-2">
                    Amazing view from the Alappuzha backwaters! The traditional houseboat experience was incredible 🛶
                  </p>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span>❤️ 24</span>
                    <span>💬 8</span>
                    <span>📤 Share</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="insights" className="p-4 mt-0">
            <div className="space-y-4">
              <h2 className="text-lg text-gray-800">Personal Insights</h2>
              
              {/* Stats Cards */}
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="text-center py-4">
                    <p className="text-2xl text-emerald-600 mb-1">1,847</p>
                    <p className="text-sm text-gray-600">Total km</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="text-center py-4">
                    <p className="text-2xl text-blue-600 mb-1">23</p>
                    <p className="text-sm text-gray-600">Cities visited</p>
                  </CardContent>
                </Card>
              </div>

              {/* Gamification Card */}
              <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                <CardContent className="py-6">
                  <h3 className="mb-2">Kerala Explorer</h3>
                  <p className="text-sm opacity-90 mb-4">You're 250 km away from your next reward!</p>
                  <Progress value={75} className="h-2 bg-white/20" />
                  <p className="text-xs mt-2 opacity-75">Next: ₹100 travel voucher</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </div>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-200">
          <TabsList className="w-full bg-transparent h-16 p-0">
            <TabsTrigger value="home" className="flex-1 flex-col gap-1 h-full">
              <Home className="h-5 w-5" />
              <span className="text-xs">Home</span>
            </TabsTrigger>
            <TabsTrigger value="trips" className="flex-1 flex-col gap-1 h-full">
              <MapPin className="h-5 w-5" />
              <span className="text-xs">Trips</span>
            </TabsTrigger>
            <TabsTrigger value="connect" className="flex-1 flex-col gap-1 h-full">
              <Users className="h-5 w-5" />
              <span className="text-xs">Connect</span>
            </TabsTrigger>
            <TabsTrigger value="community" className="flex-1 flex-col gap-1 h-full">
              <Camera className="h-5 w-5" />
              <span className="text-xs">Community</span>
            </TabsTrigger>
            <TabsTrigger value="insights" className="flex-1 flex-col gap-1 h-full">
              <BarChart3 className="h-5 w-5" />
              <span className="text-xs">Insights</span>
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Floating Action Button (when tracking) */}
        {isTracking && (
          <div className="fixed bottom-20 right-4">
            <Button
              onClick={() => setIsTracking(false)}
              size="lg"
              className="rounded-full w-14 h-14 bg-red-500 hover:bg-red-600 text-white shadow-lg"
            >
              <Pause className="h-6 w-6" />
            </Button>
          </div>
        )}
      </Tabs>
    </div>
  );
}