import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  Building2, 
  Download, 
  Calendar, 
  Users, 
  MapPin, 
  TrendingUp,
  BarChart3,
  FileSpreadsheet,
  LogOut
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

interface NatpacDashboardProps {
  onLogout: () => void;
}

export function NatpacDashboard({ onLogout }: NatpacDashboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<'month' | 'year'>('month');

  // Mock data for demonstrations
  const monthlyDestinations = [
    { destination: 'Kochi', visits: 2450, growth: 12 },
    { destination: 'Thiruvananthapuram', visits: 1890, growth: 8 },
    { destination: 'Kozhikode', visits: 1650, growth: 15 },
    { destination: 'Thrissur', visits: 1420, growth: 5 },
    { destination: 'Kannur', visits: 980, growth: -2 },
    { destination: 'Kollam', visits: 750, growth: 18 },
    { destination: 'Palakkad', visits: 680, growth: 22 },
    { destination: 'Alappuzha', visits: 590, growth: 7 }
  ];

  const yearlyDestinations = [
    { destination: 'Kochi', visits: 28500, growth: 18 },
    { destination: 'Thiruvananthapuram', visits: 22100, growth: 12 },
    { destination: 'Kozhikode', visits: 19200, growth: 25 },
    { destination: 'Thrissur', visits: 16800, growth: 8 },
    { destination: 'Kannur', visits: 11500, growth: 15 },
    { destination: 'Kollam', visits: 8900, growth: 28 },
    { destination: 'Palakkad', visits: 7650, growth: 35 },
    { destination: 'Alappuzha', visits: 6890, growth: 22 }
  ];

  const travelModes = [
    { mode: 'Bus', count: 4500, color: '#10b981' },
    { mode: 'Auto/Taxi', count: 2800, color: '#3b82f6' },
    { mode: 'Private Vehicle', count: 3200, color: '#8b5cf6' },
    { mode: 'Walking', count: 1800, color: '#f59e0b' },
    { mode: 'Bicycle', count: 650, color: '#ef4444' }
  ];

  const weeklyTrends = [
    { day: 'Mon', users: 890, trips: 1250 },
    { day: 'Tue', users: 920, trips: 1180 },
    { day: 'Wed', users: 850, trips: 1320 },
    { day: 'Thu', users: 980, trips: 1450 },
    { day: 'Fri', users: 1200, trips: 1650 },
    { day: 'Sat', users: 1100, trips: 1520 },
    { day: 'Sun', users: 750, trips: 980 }
  ];

  // Detailed trip data
  const detailedTrips = [
    {
      tripId: 'TRP001',
      userId: 'USR2847',
      origin: 'Kochi Metro Station',
      destination: 'Thiruvananthapuram Central',
      mode: 'Bus',
      startTime: '08:30 AM',
      endTime: '10:45 AM',
      date: '2025-09-19',
      accompaniedTravelers: 2,
      travelerDetails: 'Spouse, Child (Age 8)'
    },
    {
      tripId: 'TRP002',
      userId: 'USR1923',
      origin: 'Thrissur Railway Station',
      destination: 'Kozhikode Beach',
      mode: 'Private Vehicle',
      startTime: '09:15 AM',
      endTime: '11:30 AM',
      date: '2025-09-19',
      accompaniedTravelers: 3,
      travelerDetails: 'Family Members (2 Adults, 1 Child)'
    },
    {
      tripId: 'TRP003',
      userId: 'USR3456',
      origin: 'Kannur Bus Stand',
      destination: 'Wayanad District',
      mode: 'Auto/Taxi',
      startTime: '07:00 AM',
      endTime: '09:30 AM',
      date: '2025-09-19',
      accompaniedTravelers: 1,
      travelerDetails: 'Colleague'
    },
    {
      tripId: 'TRP004',
      userId: 'USR7891',
      origin: 'Alappuzha Backwaters',
      destination: 'Kollam Beach',
      mode: 'Bus',
      startTime: '02:00 PM',
      endTime: '03:45 PM',
      date: '2025-09-19',
      accompaniedTravelers: 0,
      travelerDetails: 'Solo Travel'
    },
    {
      tripId: 'TRP005',
      userId: 'USR5624',
      origin: 'Palakkad Fort',
      destination: 'Kochi Airport',
      mode: 'Private Vehicle',
      startTime: '05:30 PM',
      endTime: '07:15 PM',
      date: '2025-09-19',
      accompaniedTravelers: 4,
      travelerDetails: 'Extended Family (3 Adults, 1 Senior)'
    },
    {
      tripId: 'TRP006',
      userId: 'USR9876',
      origin: 'Munnar Hills',
      destination: 'Thekkady Wildlife Sanctuary',
      mode: 'Bus',
      startTime: '10:00 AM',
      endTime: '12:30 PM',
      date: '2025-09-18',
      accompaniedTravelers: 2,
      travelerDetails: 'Friends (2 Adults)'
    },
    {
      tripId: 'TRP007',
      userId: 'USR4321',
      origin: 'Varkala Beach',
      destination: 'Kovalam Beach',
      mode: 'Walking',
      startTime: '06:00 AM',
      endTime: '07:30 AM',
      date: '2025-09-18',
      accompaniedTravelers: 1,
      travelerDetails: 'Exercise Partner'
    },
    {
      tripId: 'TRP008',
      userId: 'USR8765',
      origin: 'Kochi Marine Drive',
      destination: 'Fort Kochi',
      mode: 'Bicycle',
      startTime: '04:30 PM',
      endTime: '05:15 PM',
      date: '2025-09-18',
      accompaniedTravelers: 0,
      travelerDetails: 'Solo Travel'
    }
  ];

  const currentData = selectedPeriod === 'month' ? monthlyDestinations : yearlyDestinations;

  const exportToExcel = (dataType: string) => {
    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `natpac_${dataType}_${selectedPeriod}_${timestamp}.csv`;
    
    let csvContent = '';
    let headers = '';
    
    // Generate appropriate CSV content based on data type
    switch (dataType) {
      case 'destinations':
        headers = 'Destination,Visits,Growth Percentage';
        csvContent = currentData.map(item => 
          `"${item.destination}",${item.visits},${item.growth}%`
        ).join('\n');
        break;
        
      case 'travel_modes':
        headers = 'Travel Mode,Trip Count';
        csvContent = travelModes.map(mode => 
          `"${mode.mode}",${mode.count}`
        ).join('\n');
        break;
        
      case 'weekly_trends':
        headers = 'Day,Active Users,Total Trips';
        csvContent = weeklyTrends.map(day => 
          `${day.day},${day.users},${day.trips}`
        ).join('\n');
        break;
        
      case 'trip_details':
        headers = 'Trip ID,User ID,Origin,Destination,Travel Mode,Start Time,End Time,Date,Accompanied Travelers,Traveler Details';
        csvContent = detailedTrips.map(trip => 
          `"${trip.tripId}","${trip.userId}","${trip.origin}","${trip.destination}","${trip.mode}","${trip.startTime}","${trip.endTime}","${trip.date}",${trip.accompaniedTravelers},"${trip.travelerDetails}"`
        ).join('\n');
        break;
        
      default:
        headers = 'Data,Value';
        csvContent = 'No data available';
    }
    
    const fullCsvContent = `${headers}\n${csvContent}`;
    const blob = new Blob([fullCsvContent], { 
      type: 'text/csv;charset=utf-8;' 
    });
    
    // Create download link
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl text-gray-900">NATPAC Analytics Portal</h1>
                <p className="text-sm text-gray-500">Kerala State Transport Planning</p>
              </div>
            </div>
            <Button 
              onClick={onLogout}
              variant="outline"
              size="sm"
              className="text-gray-600 hover:text-gray-800"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600">Active Users</p>
                  <p className="text-lg text-gray-900">25,847</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-emerald-600" />
                <div>
                  <p className="text-sm text-gray-600">Total Trips</p>
                  <p className="text-lg text-gray-900">186,429</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-600">Growth</p>
                  <p className="text-lg text-gray-900">+18.5%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600">Data Points</p>
                  <p className="text-lg text-gray-900">2.4M</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Analytics */}
        <Tabs defaultValue="destinations" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-1">
            <TabsTrigger value="destinations">Destinations</TabsTrigger>
            <TabsTrigger value="modes">Travel Modes</TabsTrigger>
            <TabsTrigger value="trends">Weekly Trends</TabsTrigger>
            <TabsTrigger value="trips">Trip Details</TabsTrigger>
          </TabsList>

          <TabsContent value="destinations">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-emerald-600" />
                    Most Visited Destinations
                  </CardTitle>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant={selectedPeriod === 'month' ? 'default' : 'outline'}
                        onClick={() => setSelectedPeriod('month')}
                        className="text-xs px-2 py-1"
                      >
                        <Calendar className="h-3 w-3 mr-1" />
                        Month
                      </Button>
                      <Button
                        size="sm"
                        variant={selectedPeriod === 'year' ? 'default' : 'outline'}
                        onClick={() => setSelectedPeriod('year')}
                        className="text-xs px-2 py-1"
                      >
                        Year
                      </Button>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => exportToExcel('destinations')}
                      className="bg-green-600 hover:bg-green-700 text-xs px-2 py-1"
                    >
                      <FileSpreadsheet className="h-3 w-3 mr-1" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-80 mb-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={currentData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                      <XAxis 
                        dataKey="destination" 
                        tick={{ fontSize: 12 }}
                        angle={-45}
                        textAnchor="end"
                        height={80}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'white', 
                          border: '1px solid #e5e7eb',
                          borderRadius: '8px'
                        }}
                        formatter={(value: any, name: string) => [
                          `${value.toLocaleString()} visits`, 
                          'Total Visits'
                        ]}
                      />
                      <Bar 
                        dataKey="visits" 
                        fill="#10b981"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                {/* Destination Table */}
                <div className="space-y-2">
                  <h4 className="text-sm text-gray-600 mb-3">Detailed Breakdown</h4>
                  {currentData.map((item, index) => (
                    <div key={item.destination} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="text-xs">{index + 1}</Badge>
                        <span className="text-gray-800">{item.destination}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-gray-600">{item.visits.toLocaleString()} visits</span>
                        <Badge 
                          variant={item.growth >= 0 ? 'default' : 'destructive'}
                          className={item.growth >= 0 ? 'bg-green-500' : ''}
                        >
                          {item.growth >= 0 ? '+' : ''}{item.growth}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="modes">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-blue-600" />
                    Travel Mode Distribution
                  </CardTitle>
                  <Button
                    size="sm"
                    onClick={() => exportToExcel('travel_modes')}
                    className="bg-green-600 hover:bg-green-700 text-xs px-2 py-1"
                  >
                    <FileSpreadsheet className="h-3 w-3 mr-1" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={travelModes}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={120}
                          dataKey="count"
                          nameKey="mode"
                        >
                          {travelModes.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'white', 
                            border: '1px solid #e5e7eb',
                            borderRadius: '8px'
                          }}
                          formatter={(value: any, name: string) => [
                            `${value.toLocaleString()} trips`, 
                            name
                          ]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-3">
                    <h4 className="text-sm text-gray-600">Mode Breakdown</h4>
                    {travelModes.map((mode) => (
                      <div key={mode.mode} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-4 h-4 rounded-full" 
                            style={{ backgroundColor: mode.color }}
                          />
                          <span className="text-gray-800">{mode.mode}</span>
                        </div>
                        <span className="text-gray-600">{mode.count.toLocaleString()} trips</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-purple-600" />
                    Weekly Activity Trends
                  </CardTitle>
                  <Button
                    size="sm"
                    onClick={() => exportToExcel('weekly_trends')}
                    className="bg-green-600 hover:bg-green-700 text-xs px-2 py-1"
                  >
                    <FileSpreadsheet className="h-3 w-3 mr-1" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={weeklyTrends} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                        <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'white', 
                            border: '1px solid #e5e7eb',
                            borderRadius: '8px'
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="users" 
                          stroke="#8b5cf6" 
                          strokeWidth={3}
                          dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 4 }}
                          name="Active Users"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="trips" 
                          stroke="#10b981" 
                          strokeWidth={3}
                          dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                          name="Total Trips"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="text-sm text-gray-600">Weekly Summary</h4>
                      {weeklyTrends.map((day) => (
                        <div key={day.day} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                          <span className="text-gray-800">{day.day}</span>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="text-purple-600">{day.users} users</span>
                            <span className="text-emerald-600">{day.trips} trips</span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex flex-col justify-center space-y-4">
                      <div className="p-4 bg-purple-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
                          <span className="text-sm text-gray-600">Peak Usage Day</span>
                        </div>
                        <p className="text-lg text-gray-900">Friday</p>
                        <p className="text-sm text-gray-500">1,200 active users</p>
                      </div>
                      <div className="p-4 bg-emerald-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-3 h-3 bg-emerald-600 rounded-full"></div>
                          <span className="text-sm text-gray-600">Most Trips</span>
                        </div>
                        <p className="text-lg text-gray-900">Friday</p>
                        <p className="text-sm text-gray-500">1,650 total trips</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trips">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-emerald-600" />
                    Individual Trip Details
                  </CardTitle>
                  <Button
                    size="sm"
                    onClick={() => exportToExcel('trip_details')}
                    className="bg-green-600 hover:bg-green-700 text-xs px-2 py-1"
                  >
                    <FileSpreadsheet className="h-3 w-3 mr-1" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <div className="min-w-full">
                    <div className="space-y-3">
                      <div className="grid grid-cols-7 gap-2 p-3 bg-gray-100 rounded-lg text-sm font-medium text-gray-700">
                        <span>Trip ID</span>
                        <span>Origin</span>
                        <span>Destination</span>
                        <span>Mode</span>
                        <span>Time</span>
                        <span>Travelers</span>
                        <span>Details</span>
                      </div>
                      {detailedTrips.map((trip) => (
                        <div key={trip.tripId} className="grid grid-cols-7 gap-2 p-3 bg-white border border-gray-200 rounded-lg text-sm">
                          <span className="font-mono text-blue-600">{trip.tripId}</span>
                          <span className="text-gray-800 truncate" title={trip.origin}>{trip.origin}</span>
                          <span className="text-gray-800 truncate" title={trip.destination}>{trip.destination}</span>
                          <Badge variant="outline" className="text-xs w-fit">
                            {trip.mode}
                          </Badge>
                          <span className="text-gray-600">{trip.startTime}</span>
                          <span className="text-center">
                            <Badge variant={trip.accompaniedTravelers > 0 ? "default" : "secondary"} className="text-xs">
                              {trip.accompaniedTravelers + 1}
                            </Badge>
                          </span>
                          <span className="text-gray-600 truncate text-xs" title={trip.travelerDetails}>
                            {trip.travelerDetails}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h4 className="text-sm font-medium text-blue-900 mb-2">Trip Data Summary</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-blue-700">Total Trips:</span>
                      <span className="ml-2 font-medium">{detailedTrips.length}</span>
                    </div>
                    <div>
                      <span className="text-blue-700">Solo Travelers:</span>
                      <span className="ml-2 font-medium">{detailedTrips.filter(t => t.accompaniedTravelers === 0).length}</span>
                    </div>
                    <div>
                      <span className="text-blue-700">Group Travelers:</span>
                      <span className="ml-2 font-medium">{detailedTrips.filter(t => t.accompaniedTravelers > 0).length}</span>
                    </div>
                    <div>
                      <span className="text-blue-700">Avg Group Size:</span>
                      <span className="ml-2 font-medium">
                        {(detailedTrips.reduce((sum, t) => sum + t.accompaniedTravelers + 1, 0) / detailedTrips.length).toFixed(1)}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}