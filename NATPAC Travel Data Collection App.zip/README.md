
  # NATPAC Travel Data Collection App

  This is a code bundle for NATPAC Travel Data Collection App. The original project is available at https://www.figma.com/design/MsOBVebI3L5LSkLglrRdVZ/NATPAC-Travel-Data-Collection-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  